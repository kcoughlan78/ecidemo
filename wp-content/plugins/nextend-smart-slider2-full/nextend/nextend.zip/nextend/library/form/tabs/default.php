<?php
nextendimport('nextend.form.tab');

class NextendTabDefault extends NextendTab {
    
}